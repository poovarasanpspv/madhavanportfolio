const express = require("express");
var cors = require("cors");
const cookieParser = require('cookie-parser');
const path = require('path');
const app = express();
app.use(cors());
app.use(cookieParser());
app.use(express.json());
app.use('/uploads/product/', express.static(path.join(__dirname,'/uploads/product/') ) )

app.use(express.static(__dirname+'/upload'));
const product = require('./routes/product');
const auth = require('./routes/auth');
const errorMiddleware = require('./Middlewares/error');
app.use("/api/v1", product);
app.use('/api/v1/',auth);

app.use('/upload', express.static('upload'));

// if(process.env.NODE_ENV === "production") {
//     app.use(express.static(path.join(__dirname, '../frontend/build')));
//     app.get('*', (req, res) =>{
//         res.sendFile(path.resolve(__dirname, '../frontend/build/index.html'))
//     })
// }


app.use(errorMiddleware);

module.exports = app;